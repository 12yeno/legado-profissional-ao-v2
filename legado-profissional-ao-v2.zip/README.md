# Legado Profissional AO — V2
Base inicial de produção: Next.js + TypeScript + Prisma + PostgreSQL.
Inclui modelos de instituições, utilizadores, alunos, documentos, planos, pagamentos e auditoria.
## Arranque
1. Node.js 20+
2. PostgreSQL
3. Copie `.env.example` para `.env`
4. `npm install`
5. `npx prisma generate`
6. `npx prisma db push`
7. `npm run dev`
## Antes de produção
Implementar sessões HttpOnly, autorização server-side, uploads privados, backups, rate limiting, validação institucional, políticas legais, integração de pagamentos e testes de segurança.
